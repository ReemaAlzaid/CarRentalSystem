
package CarRental;

import java.io.*;
import javax.swing.*;

    public class CarRental {
       private int numOfCars;
       private Car [] carlist;
    
    public CarRental(int size){
            numOfCars=0;
            carlist=new Car[size];
            loadFromFile();
    }//end constructor
    
    public void addCar(Car c){
            if( numOfCars >= carlist.length ){
            JOptionPane.showMessageDialog(null ,"Cannot add any more cars , List is full");
            return;
            }
            for( int i =0 ; i < numOfCars ; i++ )
            if( carlist[i].getPlateNo().equals(c.getPlateNo())){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "This car is already taken";
            JOptionPane.showMessageDialog(null , sr , "Add a new car" , JOptionPane.INFORMATION_MESSAGE,icon );
            return ; 
            }

            carlist[numOfCars++] = c ; 
            ImageIcon icon = new ImageIcon("src/CarRental/check.png");
            String sr = c.getClass().getSimpleName()  + " car is added successfully";
            JOptionPane.showMessageDialog(null , sr, "Add a new car" , JOptionPane.INFORMATION_MESSAGE,icon );
         }//end addCar

    public void saveToFile(){
            try{
            File file = new File("cars.dat");
            FileOutputStream fos = new FileOutputStream (file);
            ObjectOutputStream oos = new ObjectOutputStream (fos);

            for( int i = 0 ;i < this.numOfCars ; i++ )
            oos.writeObject(carlist[i]);
            oos.close();
            ImageIcon icon = new ImageIcon("src/CarRental/Thankyou.png");
            String sr =  "Thank you for using CRS, All changes is saved";
            JOptionPane.showMessageDialog(null , sr , "File is Saved" , JOptionPane.INFORMATION_MESSAGE,icon );
            }//end try
            
            catch(IOException ex  ) {
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Error cannot save the file";
            JOptionPane.showMessageDialog(null , sr , "File is not Saved" , JOptionPane.INFORMATION_MESSAGE,icon );
            }
        }//end saveToFile
    
    public void loadFromFile(){
            ObjectInputStream ois = null;
            try{
            File file = new File("cars.dat") ; 
            FileInputStream fis = new FileInputStream(file);
            ois= new ObjectInputStream( fis);

            while( true ){
                Car c = (Car) ois.readObject() ; 
                if( numOfCars >= carlist.length )
                break; 
                carlist[numOfCars++] = c ; 
            }

            }//end try
            catch(EOFException e ){
            }
            
            catch(ClassNotFoundException e ){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "File is not found";
            JOptionPane.showMessageDialog(null , sr , "Did not load" , JOptionPane.INFORMATION_MESSAGE,icon ); 
            }
            catch(IOException e  ){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Error loading the file";
            JOptionPane.showMessageDialog(null , sr , "Did not load" , JOptionPane.INFORMATION_MESSAGE,icon );   
            }

            try{  if( ois!= null ) ois.close(); } 
            catch(IOException e ){ }  
    }//end loadFromFile

    public void rentCar( String plateNo , Customer c ,int numOfDay)  {
            Car  car = this.getCar(plateNo) ; 
            if( car == null){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Could not find this Plate number";
            JOptionPane.showMessageDialog(null , sr , "Rent car" , JOptionPane.INFORMATION_MESSAGE,icon );  
            return;   
            }   

            if( car.getAvailable() == true ){
            car.setCustomer(c);
            car.setAvailable(false);
            ImageIcon icon = new ImageIcon("src/CarRental/check.png");
            String sr =  "Rented a car successfully";
            JOptionPane.showMessageDialog(null , sr , "Rent car" , JOptionPane.INFORMATION_MESSAGE,icon ); 
            
            ImageIcon ico = new ImageIcon("src/CarRental/ICON.png");
            String str =car.printBill(numOfDay);
            JOptionPane.showMessageDialog(null , str, "Car's information" , JOptionPane.INFORMATION_MESSAGE,ico ); 

            return ; }
            else{
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "This car is not available for now";
            JOptionPane.showMessageDialog(null , sr , "Rent car" , JOptionPane.INFORMATION_MESSAGE,icon );  
            return ; 
            }
    }//end rentCar

    public void returnCar(String plateNo){
        Car  car = this.getCar(plateNo) ; 

        if( car == null){
        ImageIcon icon = new ImageIcon("src/CarRental/error.png");
        String sr =  "Could not find this Plate number";
        JOptionPane.showMessageDialog(null , sr , "Return car" , JOptionPane.INFORMATION_MESSAGE,icon );  
        return;   
        }

        if( car.getAvailable() == false ){
        car.setCustomer(null);
        car.setAvailable(true);
        ImageIcon icon = new ImageIcon("src/CarRental/check.png");
        String sr =  "Returned a car successfully";
        JOptionPane.showMessageDialog(null , sr , "Return car" , JOptionPane.INFORMATION_MESSAGE,icon );  
        return ; }
        
        else{
        ImageIcon icon = new ImageIcon("src/CarRental/error.png");
        String sr =  "This car is still available";
        JOptionPane.showMessageDialog(null , sr , "Return car" , JOptionPane.INFORMATION_MESSAGE,icon ); 
        return ; 
        }
    }//end returnCar

    public VIP[] searchAvailableVIP(){
        VIP[] array = new VIP[numOfCars] ; 
        int a = 0 ; 
        for( int i = 0 ;i < numOfCars ; i++)
        if( carlist[i] instanceof VIP && carlist[i].getAvailable() == true )
        array[a++] = (VIP) carlist[i] ; 
        if( a == 0 )
        return null; 

        return array; 
    }//end SAV
    
    public  Economy[] searchAvailableEconomy(){
        Economy[] array = new Economy[numOfCars] ; 
        int a = 0 ; 
        for( int i = 0 ;i < numOfCars ; i++)
        if( carlist[i] instanceof Economy && carlist[i].getAvailable() == true )
        array[a++] = (Economy) carlist[i] ; 

        if( a == 0 )
        return null; 
        return array; 
    }//end SAE

    public Car getCar(String PN){
        for( int i = 0 ; i < numOfCars ; i++)
        if( carlist[i].getPlateNo().equals(PN))
        return carlist[i] ; 
        return null;
    }//end getCar
}//end class