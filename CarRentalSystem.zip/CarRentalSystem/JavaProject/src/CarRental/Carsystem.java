
package CarRental;
import javax.swing.*;
public class Carsystem extends javax.swing.JFrame {
  CarRental  carrental  = new CarRental(100);
    public Carsystem() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        AddCar = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        PNAdd = new javax.swing.JTextField();
        PricePerDay = new javax.swing.JTextField();
        Model = new javax.swing.JTextField();
        Color = new javax.swing.JTextField();
        Driver = new javax.swing.JPanel();
        IDAdd = new javax.swing.JTextField();
        NameAdd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        AddCarButton = new javax.swing.JToggleButton();
        Economy = new javax.swing.JRadioButton();
        VIP = new javax.swing.JRadioButton();
        ShowInformation = new javax.swing.JPanel();
        ShowEconomy = new javax.swing.JButton();
        ShowVIP = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        Return = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        PNReturn = new javax.swing.JTextField();
        ReturnCar = new javax.swing.JButton();
        Rent = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        PNRent = new javax.swing.JTextField();
        NumOD = new javax.swing.JTextField();
        RentCar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        IDRent = new javax.swing.JTextField();
        NameRent = new javax.swing.JTextField();
        PhoneNumber = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                formComponentHidden(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        jLabel1.setText("Car Rental System");

        AddCar.setBorder(javax.swing.BorderFactory.createTitledBorder("Add a new car"));
        AddCar.setToolTipText("car");
        AddCar.setFocusTraversalPolicyProvider(true);
        AddCar.setFocusable(false);

        jLabel2.setText("Plate Number :");

        jLabel3.setText("Price of the day :");

        jLabel4.setText("Car's model :");

        jLabel5.setText("Car's color :");

        Driver.setBorder(javax.swing.BorderFactory.createTitledBorder("Driver"));

        jLabel6.setText("ID :");

        jLabel7.setText("Name");

        javax.swing.GroupLayout DriverLayout = new javax.swing.GroupLayout(Driver);
        Driver.setLayout(DriverLayout);
        DriverLayout.setHorizontalGroup(
            DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DriverLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NameAdd, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                    .addComponent(IDAdd)))
        );
        DriverLayout.setVerticalGroup(
            DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DriverLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(IDAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(DriverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        AddCarButton.setText("Add a new car");
        AddCarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCarButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(Economy);
        Economy.setText("Economy");
        Economy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EconomyActionPerformed(evt);
            }
        });

        buttonGroup1.add(VIP);
        VIP.setText("VIP");
        VIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VIPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout AddCarLayout = new javax.swing.GroupLayout(AddCar);
        AddCar.setLayout(AddCarLayout);
        AddCarLayout.setHorizontalGroup(
            AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddCarLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2)
                        .addComponent(jLabel4)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addComponent(Economy, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(VIP))
                .addGap(31, 31, 31)
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AddCarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Driver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(PNAdd, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                        .addComponent(PricePerDay)
                        .addComponent(Model)
                        .addComponent(Color)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        AddCarLayout.setVerticalGroup(
            AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AddCarLayout.createSequentialGroup()
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddCarLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(PNAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AddCarLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(PricePerDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Model, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Color, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGroup(AddCarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AddCarLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(Driver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(AddCarLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(Economy)
                        .addGap(18, 18, 18)
                        .addComponent(VIP)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AddCarButton))
        );

        ShowInformation.setBorder(javax.swing.BorderFactory.createTitledBorder("Show information"));

        ShowEconomy.setText("Show all available Economy");
        ShowEconomy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowEconomyActionPerformed(evt);
            }
        });

        ShowVIP.setText("Show all available VIP");
        ShowVIP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowVIPActionPerformed(evt);
            }
        });

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout ShowInformationLayout = new javax.swing.GroupLayout(ShowInformation);
        ShowInformation.setLayout(ShowInformationLayout);
        ShowInformationLayout.setHorizontalGroup(
            ShowInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(ShowInformationLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ShowEconomy)
                .addGap(42, 42, 42)
                .addComponent(ShowVIP, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                .addGap(28, 28, 28))
        );
        ShowInformationLayout.setVerticalGroup(
            ShowInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ShowInformationLayout.createSequentialGroup()
                .addGroup(ShowInformationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ShowEconomy)
                    .addComponent(ShowVIP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Return.setBorder(javax.swing.BorderFactory.createTitledBorder("Return Car"));

        jLabel8.setText("Plate Number :");

        ReturnCar.setText("Retrun");
        ReturnCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnCarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ReturnLayout = new javax.swing.GroupLayout(Return);
        Return.setLayout(ReturnLayout);
        ReturnLayout.setHorizontalGroup(
            ReturnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReturnLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(jLabel8)
                .addGap(56, 56, 56)
                .addComponent(PNReturn, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ReturnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ReturnCar, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(247, 247, 247))
        );
        ReturnLayout.setVerticalGroup(
            ReturnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ReturnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ReturnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(PNReturn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ReturnCar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Rent.setBorder(javax.swing.BorderFactory.createTitledBorder("Rent a Car"));

        jLabel9.setText("Plate Number :");

        jLabel10.setText("Number of Days :");

        NumOD.setText("1");

        RentCar.setText("Rent");
        RentCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RentCarActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Customer information"));

        jLabel11.setText("ID :");

        jLabel12.setText("Name :");

        jLabel13.setText("Phone Number :");

        PhoneNumber.setText("+966");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel11)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(IDRent)
                    .addComponent(NameRent)
                    .addComponent(PhoneNumber, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(IDRent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(NameRent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PhoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout RentLayout = new javax.swing.GroupLayout(Rent);
        Rent.setLayout(RentLayout);
        RentLayout.setHorizontalGroup(
            RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RentLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RentLayout.createSequentialGroup()
                        .addGroup(RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel9))
                        .addGap(55, 55, 55)
                        .addGroup(RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(PNRent, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(NumOD, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(115, 115, 115))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RentLayout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(60, 60, 60))))
            .addGroup(RentLayout.createSequentialGroup()
                .addGap(243, 243, 243)
                .addComponent(RentCar)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        RentLayout.setVerticalGroup(
            RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RentLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PNRent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(RentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NumOD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(RentCar)
                .addContainerGap())
        );

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/CarRental/Car pic.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(AddCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(ShowInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Rent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Return, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddCar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ShowInformation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Rent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Return, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        AddCar.getAccessibleContext().setAccessibleParent(jLabel1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void AddCarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCarButtonActionPerformed
        if(Economy.isSelected()){
                if (PNAdd.getText().equals("")||PricePerDay.getText().equals("")||Model.getText().equals("")||Color.getText().equals("")){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Must full all available inputs";
            JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
            return;}
            }
            if(!Economy.isSelected()&&!VIP.isSelected()){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Select Economy or VIP";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
            return;}
            
            if (VIP.isSelected()){
            if (PNAdd.getText().equals("")||PricePerDay.getText().equals("")||Model.getText().equals("")||Color.getText().equals("")||IDAdd.getText().equals("")||NameAdd.getText().equals("")){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Must full all available inputs";
            JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
              return;}}

              try{
            String platenum = PNAdd.getText();  
            double price = Double.parseDouble(PricePerDay.getText()) ; 
            String model = Model.getText() ; 
            String color = Color.getText() ; 

            if( model.length() <= 2  || color.length() <= 2  ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "The length of the inputs must contain more than or 2 characters or 2 numbers";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ;}
            
            if( platenum.length() <= 3 ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "The Plate number has to be more than 3 numbers";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ; }
            
            if( price <= 50 ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Price has to be more than 50 SAR";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ;  
            }

            if (Economy.isSelected()){
                Economy e1 = new Economy(platenum , price , model , color ) ;
                carrental.addCar(e1);
            }
            
            if (VIP.isSelected()){

                int ID = Integer.parseInt(IDAdd.getText());
                String Name = NameAdd.getText();
                if( ID == 0 ||Name.length() <= 2  ){
                    ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                    String sr =  "The length of ID and Name must contain 2 characters or 2 numbers";
                    JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                      return;}
                Driver d1 = new Driver(ID, Name ) ; 
                VIP v1 = new VIP(platenum , price , model , color , d1 ) ;
                carrental.addCar(v1);
              }//end elseif
            }//end try


             catch( NumberFormatException e ){
              if(Economy.isSelected()){
                  ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                    String sr =  "Must enter numbers in the Plate number,Price";
                    JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                    return;}
              if (VIP.isSelected()){
                  ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                  String sr =  "Must enter numbers in the Plate number,Price and ID";
                  JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
              return;}}
                

          PNAdd.setText(""); 
          PricePerDay.setText("");
          Model.setText(""); 
          Color.setText(""); 
          IDAdd.setText("");
          NameAdd.setText(""); 
      
    
    }//GEN-LAST:event_AddCarButtonActionPerformed

    private void ShowEconomyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowEconomyActionPerformed
            Economy[] e= carrental.searchAvailableEconomy() ; 
        
            if( e == null)
            {
              jTextArea1.setText("No economy cars are avaliable");
              return ; 
            }
            else
             jTextArea1.setText("");
            for( int i = 0 ; i < e.length ; i++)
            {
                if( e[i] != null )
                    jTextArea1.append(e[i].toString());
            }
    }//GEN-LAST:event_ShowEconomyActionPerformed

    private void ShowVIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowVIPActionPerformed
            VIP[] v= carrental.searchAvailableVIP(); 

            if( v == null)
            {
              jTextArea1.setText("No VIP cars are avaliable");
              return ; 
            }
            else
             jTextArea1.setText("");
            for( int i = 0 ; i < v.length ; i++)
            {
                if( v[i] != null ){
                jTextArea1.append(v[i].toString());
                jTextArea1.append(( (VIP)v[i] ).getDriver().toString());
                }

            }  
    }//GEN-LAST:event_ShowVIPActionPerformed

    private void RentCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RentCarActionPerformed
            if (PNRent.getText().equals("")||NumOD.getText().equals("")||IDRent.getText().equals("")||NameRent.getText().equals("")||PhoneNumber.getText().equals("")){
            ImageIcon icon = new ImageIcon("src/CarRental/error.png");
            String sr =  "Must full all available inputs";
            JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
              return;}
            
            int numDays = 0 ; 
            String PlateN  = ""; 
            int ID =0;
            String name ="";
            long phone =0;
            Customer cr=null;
            
            try{
              PlateN = PNRent.getText(); 
              numDays = Integer.parseInt( NumOD.getText()); 
              ID=Integer.parseInt( IDRent.getText()); 
              name = NameRent.getText();
              phone = Long.parseLong(PhoneNumber.getText()); 

             if( name.length() <= 2 ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Name has to be more than 2 characters";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ; }

            if( PlateN.length() <= 3 ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "The Plate number has to be more than 3 numbers";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ; }
            
            if( ((phone+"").length()) !=12){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Phone number has to be equal to 10 numbers";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ; }
            
            if(ID==0){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Enter the ID number again";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ; }
           
            }
            catch(NumberFormatException e ){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Number Of Days and Plate number has to contain numbers only";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return ;}
            
            cr = new Customer(ID, name , phone ) ;
            carrental.rentCar(PlateN, cr, numDays);
            
            PNRent.setText("");
            NumOD.setText("1"); //Maximum days is 1 
            IDRent.setText("");
            NameRent.setText("");
            PhoneNumber.setText("");
    }//GEN-LAST:event_RentCarActionPerformed

    private void EconomyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EconomyActionPerformed
        
            if(Economy.isSelected()){
                IDAdd.setText("");
                NameAdd.setText("");
                IDAdd.setEnabled(false);
                NameAdd.setEnabled(false);
                jLabel6.setEnabled(false);
                jLabel7.setEnabled(false);

        }
    }//GEN-LAST:event_EconomyActionPerformed

    private void VIPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VIPActionPerformed
        
            if(VIP.isSelected()){
                IDAdd.setEnabled(true);
                NameAdd.setEnabled(true);
                jLabel6.setEnabled(true);
                jLabel7.setEnabled(true);
        }
        
    }//GEN-LAST:event_VIPActionPerformed

    private void ReturnCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnCarActionPerformed

            if (PNReturn.getText().equals("")){
                ImageIcon icon = new ImageIcon("src/CarRental/error.png");
                String sr =  "Must full the available input";
                JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
                return;}
            
            String Platenum = PNReturn.getText() ; 
            if( Platenum.length() <= 3 ){
               ImageIcon icon = new ImageIcon("src/CarRental/error.png");
               String sr =  "Plate number has to contain more than or equal to 3 numbers";
               JOptionPane.showMessageDialog(this , sr , "Error" , JOptionPane.INFORMATION_MESSAGE,icon );
               return ;} 
            
            carrental.returnCar(Platenum);

            PNReturn.setText("");
    }//GEN-LAST:event_ReturnCarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
            int num =  JOptionPane.showConfirmDialog(this,  "Do you want to save all changes?" ,"Save and Exit" , JOptionPane.YES_NO_OPTION) ; 
       
            if( num == JOptionPane.YES_OPTION){
                carrental.saveToFile();}
            else
            if( num == JOptionPane.NO_OPTION){    
            ImageIcon icon = new ImageIcon("src/CarRental/Thankyou.png");
            String sr =  "Thank you for using CRS , All changes is not saved";
            JOptionPane.showMessageDialog(null , sr , "File is Saved" , JOptionPane.INFORMATION_MESSAGE,icon );
            }  

            
    }//GEN-LAST:event_formWindowClosing

    private void formComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentHidden
    
    }//GEN-LAST:event_formComponentHidden
    
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carsystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carsystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carsystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carsystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Carsystem().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AddCar;
    private javax.swing.JToggleButton AddCarButton;
    private javax.swing.JTextField Color;
    private javax.swing.JPanel Driver;
    private javax.swing.JRadioButton Economy;
    private javax.swing.JTextField IDAdd;
    private javax.swing.JTextField IDRent;
    private javax.swing.JTextField Model;
    private javax.swing.JTextField NameAdd;
    private javax.swing.JTextField NameRent;
    private javax.swing.JTextField NumOD;
    private javax.swing.JTextField PNAdd;
    private javax.swing.JTextField PNRent;
    private javax.swing.JTextField PNReturn;
    private javax.swing.JTextField PhoneNumber;
    private javax.swing.JTextField PricePerDay;
    private javax.swing.JPanel Rent;
    private javax.swing.JButton RentCar;
    private javax.swing.JPanel Return;
    private javax.swing.JButton ReturnCar;
    private javax.swing.JButton ShowEconomy;
    private javax.swing.JPanel ShowInformation;
    private javax.swing.JButton ShowVIP;
    private javax.swing.JRadioButton VIP;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
