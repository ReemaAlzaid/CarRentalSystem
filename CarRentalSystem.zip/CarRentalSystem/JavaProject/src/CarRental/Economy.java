package CarRental;

import java.io.*;
import javax.swing.*;

public class Economy extends Car {

    public Economy(String plate, double price, String model, String color) {
        super(plate, price, model, color);
    }

   
    public String printBill(int days) {

        double totalPrice = pricePerDay * days;

        if (days > 7) {
            totalPrice -= (totalPrice * 0.20);
        }

        String s = "Economy Car Bill : \n " +  super.toString() + "\n"; 
        s = s + " Total price : " + totalPrice + "\n" ; 

        String fileName = getCustomer().getName()+ "_" +getCustomer().getId() + ".txt" ; 
        try
        {
 
        File file = new File(fileName) ; 
        FileOutputStream fos = new FileOutputStream(file) ; 
        PrintWriter pw = new PrintWriter(fos) ; 

        pw.println( s );
        pw.close();

        }
        catch(IOException ex ){
        ImageIcon icon = new ImageIcon("src/CarRental/error.png");
        String sr =  "Error cannot save the file";
        JOptionPane.showMessageDialog(null , sr , "File is not Saved" , JOptionPane.INFORMATION_MESSAGE,icon );
        }


return s ; 
    }
}
