
package CarRental;
import java.io.Serializable;

public abstract class Car implements Payable , Serializable{

protected String plateNo ; 
protected double pricePerDay ; 
protected String model; 
protected String color ; 
protected boolean available ;  
protected Customer  cr ; 

    public Car(String plate, double price, String model, String color) {
        plateNo = plate;
        pricePerDay = price;
        this.model = model;
        this.color = color;
        this.available = true; 
    }

    public String getPlateNo() {
        return plateNo;
    }
    public Customer getCustomer() {
        return cr;}
    
    public void setCustomer(Customer cr) {
        this.cr = cr;
    }

    public boolean getAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String toString() {
        String s =  "Plate Number : " + plateNo + ", Price of the the day : " + pricePerDay + ", Model : " + model + 
                "\n Car color : " + color + ", Availability : " + available + "\n" ; 
        
        if( cr != null )
             s = s +  " Customer : " + cr.toString() + "\n";
        
        return s ; 
    }

    

    
}

