
package CarRental;

public interface Payable {
    public String printBill(int days) ; 

}
